import 'package:flutter/material.dart';

void main() => runApp(const Sou9DZApp());

const orange = Color(0xFFFF7A1A);
const ink = Color(0xFF171717);

class Sou9DZApp extends StatelessWidget {
  const Sou9DZApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'Sou9DZ',
    theme: ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(seedColor: orange),
      scaffoldBackgroundColor: const Color(0xFFF7F7F7),
    ),
    home: const HomePage(),
  );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int tab = 0;
  final categories = const [
    ('سيارات', Icons.directions_car_filled_outlined),
    ('عقارات', Icons.home_work_outlined),
    ('هواتف', Icons.smartphone),
    ('إلكترونيات', Icons.devices_other),
    ('ملابس', Icons.checkroom_outlined),
    ('أثاث', Icons.chair_outlined),
    ('خدمات', Icons.handyman_outlined),
    ('أخرى', Icons.grid_view_rounded),
  ];

  @override
  Widget build(BuildContext context) => Directionality(
    textDirection: TextDirection.rtl,
    child: Scaffold(
      appBar: AppBar(
        backgroundColor: ink,
        foregroundColor: Colors.white,
        title: const Row(children: [
          Icon(Icons.storefront, color: orange, size: 27),
          SizedBox(width: 8),
          Text('Sou9DZ', style: TextStyle(fontWeight: FontWeight.w900)),
        ]),
        actions: [IconButton(onPressed: () {}, icon: const Icon(Icons.notifications_none))],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 18, 16, 24),
        children: [
          const Text('بيع واشري بكل سهولة 🇩🇿',
            style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900, color: ink)),
          const SizedBox(height: 5),
          Text('سوقك الإلكتروني في كامل الجزائر', style: TextStyle(color: Colors.grey.shade700)),
          const SizedBox(height: 18),
          TextField(decoration: InputDecoration(
            hintText: 'واش راك تحوس؟',
            prefixIcon: const Icon(Icons.search),
            filled: true, fillColor: Colors.white,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
          )),
          const SizedBox(height: 22),
          const Text('الأقسام', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          GridView.builder(
            shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
            itemCount: categories.length,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 4, mainAxisSpacing: 12, crossAxisSpacing: 10, childAspectRatio: .92),
            itemBuilder: (context, i) => Container(
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
              child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                Container(padding: const EdgeInsets.all(11),
                  decoration: BoxDecoration(color: orange.withOpacity(.12), shape: BoxShape.circle),
                  child: Icon(categories[i].$2, color: orange, size: 24)),
                const SizedBox(height: 7),
                Text(categories[i].$1, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
              ]),
            ),
          ),
          const SizedBox(height: 22),
          const Text('إعلانات تجريبية', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          const AdCard(title: 'هاتف Samsung Galaxy', price: '45.000 دج', place: 'الجزائر العاصمة', icon: Icons.phone_android),
          const SizedBox(height: 12),
          const AdCard(title: 'أريكة صالون بحالة جيدة', price: '38.000 دج', place: 'عنابة', icon: Icons.weekend_outlined),
          const SizedBox(height: 12),
          const AdCard(title: 'سيارة مستعملة - حالة ممتازة', price: '185 مليون', place: 'قسنطينة', icon: Icons.directions_car),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: orange, foregroundColor: Colors.white,
        onPressed: () => showModalBottomSheet(context: context, builder: (_) => const Directionality(
          textDirection: TextDirection.rtl,
          child: Padding(padding: EdgeInsets.all(24), child: Text(
            'إضافة إعلان\\n\\nسنضيف في المرحلة القادمة نموذج الصور والعنوان والسعر والولاية.',
            style: TextStyle(fontSize: 18, height: 1.8, fontWeight: FontWeight.w600))),
        )),
        icon: const Icon(Icons.add), label: const Text('أضف إعلان'),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (v) => setState(() => tab = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'الرئيسية'),
          NavigationDestination(icon: Icon(Icons.favorite_border), label: 'المفضلة'),
          NavigationDestination(icon: Icon(Icons.chat_bubble_outline), label: 'الرسائل'),
          NavigationDestination(icon: Icon(Icons.person_outline), label: 'حسابي'),
        ],
      ),
    ),
  );
}

class AdCard extends StatelessWidget {
  final String title, price, place;
  final IconData icon;
  const AdCard({super.key, required this.title, required this.price, required this.place, required this.icon});

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(12),
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(17)),
    child: Row(children: [
      Container(width: 82, height: 82, decoration: BoxDecoration(
        color: const Color(0xFFFFE9D9), borderRadius: BorderRadius.circular(13)),
        child: Icon(icon, color: orange, size: 38)),
      const SizedBox(width: 12),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
        const SizedBox(height: 6),
        Text(price, style: const TextStyle(color: orange, fontWeight: FontWeight.w900, fontSize: 16)),
        const SizedBox(height: 5),
        Row(children: [const Icon(Icons.location_on_outlined, size: 14, color: Colors.grey),
          Text(place, style: const TextStyle(color: Colors.grey, fontSize: 12))]),
      ])),
      IconButton(onPressed: () {}, icon: const Icon(Icons.favorite_border, color: Colors.grey)),
    ]),
  );
}
