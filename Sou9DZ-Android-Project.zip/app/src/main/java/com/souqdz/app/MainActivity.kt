package com.souqdz.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Orange = Color(0xFFFF781F)
private val Dark = Color(0xFF171717)
private val Pale = Color(0xFFFFE9D8)

data class Ad(val title: String, val price: String, val city: String, val category: String, val icon: ImageVector, val id: Int)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { Sou9DZApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Sou9DZApp() {
    val categories = listOf(
        "سيارات" to Icons.Default.DirectionsCar, "عقارات" to Icons.Default.HomeWork,
        "هواتف" to Icons.Default.Smartphone, "إلكترونيات" to Icons.Default.Devices,
        "ملابس" to Icons.Default.Checkroom, "أثاث" to Icons.Default.Weekend,
        "خدمات" to Icons.Default.Handyman, "أخرى" to Icons.Default.Category
    )
    val ads = remember { mutableStateListOf(
        Ad("Samsung Galaxy بحالة ممتازة", "45 000 دج", "سطيف", "هواتف", Icons.Default.Smartphone, 1),
        Ad("صالون عصري مستعمل", "38 000 دج", "عنابة", "أثاث", Icons.Default.Weekend, 2),
        Ad("سيارة للبيع، حالة جيدة", "185 مليون", "قسنطينة", "سيارات", Icons.Default.DirectionsCar, 3)
    ) }
    val favorites = remember { mutableStateListOf<Int>() }
    var search by remember { mutableStateOf("") }
    var selectedTab by remember { mutableIntStateOf(0) }
    var selectedCategory by remember { mutableStateOf<String?>(null) }
    var showAdd by remember { mutableStateOf(false) }
    val filtered = ads.filter {
        (selectedTab != 1 || favorites.contains(it.id)) &&
        (selectedCategory == null || it.category == selectedCategory) &&
        (search.isBlank() || "${it.title} ${it.city} ${it.category}".contains(search, true))
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = Orange, secondary = Dark, background = Color(0xFFF7F7F7))) {
        CompositionLocalProvider(LocalLayoutDirection provides androidx.compose.ui.unit.LayoutDirection.Rtl) {
            Scaffold(
                topBar = { TopAppBar(title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Storefront, null, tint = Orange, modifier = Modifier.size(29.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Sou9DZ", fontWeight = FontWeight.Black, color = Color.White)
                    }
                }, colors = TopAppBarDefaults.topAppBarColors(containerColor = Dark)) },
                floatingActionButton = { ExtendedFloatingActionButton(
                    onClick = { showAdd = true }, containerColor = Orange, contentColor = Color.White,
                    icon = { Icon(Icons.Default.Add, null) }, text = { Text("أضف إعلان") }
                ) },
                bottomBar = { NavigationBar {
                    NavigationBarItem(selectedTab == 0, { selectedTab = 0; selectedCategory = null }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("الرئيسية") })
                    NavigationBarItem(selectedTab == 1, { selectedTab = 1 }, icon = { Icon(Icons.Default.Favorite, null) }, label = { Text("المفضلة") })
                    NavigationBarItem(selectedTab == 2, { selectedTab = 2 }, icon = { Icon(Icons.Default.Chat, null) }, label = { Text("الرسائل") })
                    NavigationBarItem(selectedTab == 3, { selectedTab = 3 }, icon = { Icon(Icons.Default.Person, null) }, label = { Text("حسابي") })
                } }
            ) { padding ->
                if (selectedTab >= 2) {
                    Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                        Text(if (selectedTab == 2) "الرسائل ستتوفر في التحديث القادم" else "الملف الشخصي")
                    }
                } else {
                    LazyColumn(Modifier.fillMaxSize().padding(padding), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        item {
                            Text("بيع واشري بكل سهولة 🇩🇿", fontSize = 23.sp, fontWeight = FontWeight.Black, color = Dark)
                            Text("سوقك الإلكتروني في كامل الجزائر", color = Color.Gray)
                        }
                        item {
                            OutlinedTextField(search, { search = it }, modifier = Modifier.fillMaxWidth(),
                                placeholder = { Text("قلب على سلعة، قسم أو ولاية") }, leadingIcon = { Icon(Icons.Default.Search, null) },
                                singleLine = true, shape = RoundedCornerShape(16.dp))
                        }
                        if (selectedTab == 0) item {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("الأقسام", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                TextButton(onClick = { selectedCategory = null }) { Text("عرض الكل") }
                            }
                            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                categories.chunked(4).forEach { row ->
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        row.forEach { (name, icon) ->
                                            Column(Modifier.weight(1f).background(Color.White, RoundedCornerShape(14.dp))
                                                .clickable { selectedCategory = if (selectedCategory == name) null else name }
                                                .padding(vertical = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                                Icon(icon, null, tint = Orange, modifier = Modifier.size(25.dp))
                                                Spacer(Modifier.height(5.dp))
                                                Text(name, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                                            }
                                        }
                                        repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
                                    }
                                }
                            }
                        }
                        item { Text(if (selectedTab == 1) "إعلاناتك المفضلة" else "أحدث الإعلانات", fontSize = 18.sp, fontWeight = FontWeight.Bold) }
                        if (filtered.isEmpty()) item { Text("ما لقينا حتى إعلان. جرّب كلمة أخرى.", color = Color.Gray) }
                        else items(filtered, key = { it.id }) { ad ->
                            AdCard(ad, favorites.contains(ad.id)) {
                                if (favorites.contains(ad.id)) favorites.remove(ad.id) else favorites.add(ad.id)
                            }
                        }
                        item { Spacer(Modifier.height(72.dp)) }
                    }
                }
            }
        }
        if (showAdd) AddAdDialog(categories.map { it.first }, { showAdd = false }) { title, price, city, category ->
            val icon = categories.firstOrNull { it.first == category }?.second ?: Icons.Default.Category
            ads.add(0, Ad(title, "$price دج", city, category, icon, (ads.maxOfOrNull { it.id } ?: 0) + 1))
            showAdd = false
        }
    }
}

@Composable
fun AdCard(ad: Ad, favorite: Boolean, onFavorite: () -> Unit) {
    Card(shape = RoundedCornerShape(17.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(78.dp).background(Pale, RoundedCornerShape(13.dp)), contentAlignment = Alignment.Center) {
                Icon(ad.icon, null, tint = Orange, modifier = Modifier.size(37.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(ad.title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Spacer(Modifier.height(5.dp))
                Text(ad.price, color = Orange, fontWeight = FontWeight.Black, fontSize = 16.sp)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.LocationOn, null, tint = Color.Gray, modifier = Modifier.size(14.dp))
                    Text(ad.city, color = Color.Gray, fontSize = 12.sp)
                }
            }
            IconButton(onClick = onFavorite) {
                Icon(if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null,
                    tint = if (favorite) Color.Red else Color.Gray)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddAdDialog(categories: List<String>, onDismiss: () -> Unit, onPublish: (String, String, String, String) -> Unit) {
    var title by remember { mutableStateOf("") }
    var price by remember { mutableStateOf("") }
    var city by remember { mutableStateOf("") }
    var category by remember { mutableStateOf(categories.first()) }
    var expanded by remember { mutableStateOf(false) }
    AlertDialog(onDismissRequest = onDismiss,
        title = { Text("أضف إعلان جديد", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(title, { title = it }, label = { Text("عنوان السلعة") }, singleLine = true)
                OutlinedTextField(price, { price = it }, label = { Text("السعر بالدينار") }, singleLine = true)
                OutlinedTextField(city, { city = it }, label = { Text("الولاية أو البلدية") }, singleLine = true)
                ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
                    OutlinedTextField(category, {}, readOnly = true, label = { Text("القسم") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
                        modifier = Modifier.menuAnchor().fillMaxWidth())
                    ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                        categories.forEach { item ->
                            DropdownMenuItem(text = { Text(item) }, onClick = { category = item; expanded = false })
                        }
                    }
                }
            }
        },
        confirmButton = { Button(onClick = {
            if (title.isNotBlank() && price.isNotBlank() && city.isNotBlank()) onPublish(title.trim(), price.trim(), city.trim(), category)
        }) { Text("نشر الإعلان") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}
